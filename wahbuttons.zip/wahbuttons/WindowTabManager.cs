using ImGuiNET;
using System.Numerics;
using WahButtons.Helpers;
using WahButtons.Windows;
using Dalamud.Interface;

namespace WahButtons.UI;

public class WindowTabManager
{
    private readonly Configuration Configuration;

    public WindowTabManager(Configuration configuration)
    {
        Configuration = configuration;
    }

    public void DrawWindowTab(ButtonWindow window)
    {
        var config = window.Config;

        // Window Name input
        var name = config.Name;
        ImGui.Text("Window Name");
        if (ImGui.InputText("##WindowName", ref name, 32))
        {
            config.Name = name;
            Configuration.Save();
        }

        ImGui.Spacing();

        // Window Options
        var isVisible = config.IsVisible;
        if (ImGui.Checkbox("Show Window", ref isVisible))
        {
            config.IsVisible = isVisible;
            window.IsOpen = isVisible;
            Configuration.Save();
        }

        var isLocked = config.IsLocked;
        if (ImGui.Checkbox("Lock Position", ref isLocked))
        {
            config.IsLocked = isLocked;
            Configuration.Save();
        }

        var transparentBg = config.TransparentBackground;
        if (ImGui.Checkbox("Transparent Background", ref transparentBg))
        {
            config.TransparentBackground = transparentBg;
            Configuration.Save();
        }

        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Spacing();

        // Layout Selection
        ImGui.Text("Button Layout:");

        var layout = config.Layout;
        if (ImGui.RadioButton("Vertical", layout == Configuration.ButtonLayout.Vertical))
        {
            config.Layout = Configuration.ButtonLayout.Vertical;
            Configuration.Save();
        }
        ImGui.SameLine();
        if (ImGui.RadioButton("Horizontal", layout == Configuration.ButtonLayout.Horizontal))
        {
            config.Layout = Configuration.ButtonLayout.Horizontal;
            Configuration.Save();
        }
        ImGui.SameLine();
        if (ImGui.RadioButton("Grid", layout == Configuration.ButtonLayout.Grid))
        {
            config.Layout = Configuration.ButtonLayout.Grid;
            Configuration.Save();
        }

        if (layout == Configuration.ButtonLayout.Grid)
        {
            var rows = config.GridRows;
            if (ImGui.DragInt("Grid Rows", ref rows, 0.1f, 1, 10))
            {
                config.GridRows = rows;
                Configuration.Save();
            }

            var cols = config.GridColumns;
            if (ImGui.DragInt("Grid Columns", ref cols, 0.1f, 1, 10))
            {
                config.GridColumns = cols;
                Configuration.Save();
            }
        }

        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Spacing();

        // Button Management
        if (ImGuiHelper.IconButton("Add New Button", FontAwesomeIcon.Plus))
        {
            config.Buttons.Add(new Configuration.ButtonData("New Button", "/e Hello!", 75));
            Configuration.Save();
        }

        ImGui.Spacing();

        // Button List Table
        if (ImGui.BeginTable("##buttons", 5, ImGuiTableFlags.BordersInnerH))
        {
            ImGui.TableSetupColumn("##order", ImGuiTableColumnFlags.WidthFixed, 80);
            ImGui.TableSetupColumn("Label", ImGuiTableColumnFlags.WidthStretch);
            ImGui.TableSetupColumn("Command", ImGuiTableColumnFlags.WidthStretch);
            ImGui.TableSetupColumn("Size", ImGuiTableColumnFlags.WidthFixed, 100);
            ImGui.TableSetupColumn("##actions", ImGuiTableColumnFlags.WidthFixed, 30);

            for (int i = 0; i < config.Buttons.Count; i++)
            {
                ImGui.TableNextRow();
                var button = config.Buttons[i];

                // Move/Order Column
                ImGui.TableNextColumn();
                ImGui.PushID($"move_{i}");
                if (i > 0)
                {
                    if (ImGuiHelper.IconButton("##up", FontAwesomeIcon.ArrowUp))
                    {
                        var temp = config.Buttons[i];
                        config.Buttons[i] = config.Buttons[i - 1];
                        config.Buttons[i - 1] = temp;
                        Configuration.Save();
                    }
                    ImGui.SameLine();
                }
                if (i < config.Buttons.Count - 1)
                {
                    if (ImGuiHelper.IconButton("##down", FontAwesomeIcon.ArrowDown))
                    {
                        var temp = config.Buttons[i];
                        config.Buttons[i] = config.Buttons[i + 1];
                        config.Buttons[i + 1] = temp;
                        Configuration.Save();
                    }
                }
                ImGui.PopID();

                // Label Column
                ImGui.TableNextColumn();
                ImGui.PushID($"label_{i}");
                var label = button.Label;
                if (ImGui.InputText("##label", ref label, 32))
                {
                    button.Label = label;
                    Configuration.Save();
                }
                ImGui.PopID();

                // Command Column
                ImGui.TableNextColumn();
                ImGui.PushID($"command_{i}");
                var command = button.Command;
                if (ImGui.InputText("##command", ref command, 64))
                {
                    button.Command = command;
                    Configuration.Save();
                }
                ImGui.PopID();

                // Size Column 
                ImGui.TableNextColumn();
                ImGui.PushID($"size_{i}");
                var size = new Vector2(button.Width, button.Height);
                if (ImGui.DragFloat2("##size", ref size, 1, 20, 500))
                {
                    button.Width = size.X;
                    button.Height = size.Y;
                    Configuration.Save();
                }
                ImGui.PopID();

                // Delete Column
                ImGui.TableNextColumn();
                ImGui.PushID($"delete_{i}");
                if (ImGuiHelper.DeleteButton($"button_{i}"))
                {
                    config.Buttons.RemoveAt(i);
                    Configuration.Save();
                    i--;
                }
                ImGui.PopID();
            }
            ImGui.EndTable();
        }

        ImGui.Spacing();
    }
}
