using ImGuiNET;
using System.Numerics;
using Dalamud.Interface;

namespace WahButtons.Helpers;

public static class ImGuiHelper
{
    public static readonly Vector4 DefaultColor = new(0.2f, 0.2f, 0.2f, 1.0f);
    public static readonly Vector4 DeleteColor = new(0.7f, 0.2f, 0.2f, 1.0f);

    public static void SetStyles()
    {
        var style = ImGui.GetStyle();
        style.FrameRounding = 4;
        style.WindowRounding = 4;
        style.PopupRounding = 4;
        style.ScrollbarRounding = 4;
        style.FramePadding = new Vector2(4, 4);
        style.ItemSpacing = new Vector2(8, 4);
        style.WindowTitleAlign = new Vector2(0.5f, 0.5f);
    }

    public static bool IconButton(string label, FontAwesomeIcon icon, Vector4? color = null)
    {
        if (color.HasValue)
        {
            ImGui.PushStyleColor(ImGuiCol.Button, color.Value);
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, color.Value * 1.2f);
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, color.Value * 0.8f);
        }

        var result = ImGui.Button($"{icon.ToIconString()} {label}");

        if (color.HasValue)
        {
            ImGui.PopStyleColor(3);
        }

        return result;
    }

    public static bool DeleteButton(string id)
    {
        ImGui.PushStyleColor(ImGuiCol.Button, DeleteColor);
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, DeleteColor * 1.2f);
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, DeleteColor * 0.8f);

        var result = ImGui.Button($"{FontAwesomeIcon.Trash.ToIconString()}##{id}");

        ImGui.PopStyleColor(3);

        return result;
    }

    public static bool IconText(string label, FontAwesomeIcon icon)
    {
        ImGui.Text($"{icon.ToIconString()} {label}");
        return true;
    }
}
