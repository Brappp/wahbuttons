using System;
using System.Collections.Generic;
using System.Numerics;
using Dalamud.Interface.Windowing;
using ImGuiNET;
using WahButtons.Windows;
using WahButtons.Helpers;
using WahButtons.UI;
using Dalamud.Interface;

namespace WahButtons;

public class MainWindow : Window, IDisposable
{
    private readonly Plugin Plugin;
    private readonly Configuration Configuration;
    private readonly WindowSystem WindowSystem;
    private readonly WindowTabManager TabManager;

    public List<ButtonWindow> ButtonWindows = new();
    private ButtonWindow? SelectedWindowToDelete = null;
    private bool showDeleteConfirmation = false;

    public MainWindow(Plugin plugin, Configuration configuration, WindowSystem windowSystem)
        : base("Wah Buttons Configuration")
    {
        Plugin = plugin;
        Configuration = configuration;
        WindowSystem = windowSystem;
        TabManager = new WindowTabManager(configuration);

        // Set default size
        Size = new Vector2(600, 400);
        SizeCondition = ImGuiCond.FirstUseEver;

        // Load ButtonWindows from configuration
        foreach (var config in Configuration.Windows)
        {
            AddButtonWindowFromConfig(config);
        }
    }

    public void Dispose()
    {
        SaveAllButtonWindows();
    }

    public override void PreDraw()
    {
        base.PreDraw();
        ImGuiHelper.SetStyles();
    }

    public override void Draw()
    {
        if (ImGuiHelper.IconButton("Add Window", FontAwesomeIcon.Plus))
        {
            var newConfig = new Configuration.ButtonWindowConfig
            {
                Name = $"Window {ButtonWindows.Count + 1}",
                IsVisible = true,
                Layout = Configuration.ButtonLayout.Grid,
                GridRows = 2,
                GridColumns = 2
            };

            Configuration.Windows.Add(newConfig);
            AddButtonWindowFromConfig(newConfig);
            Configuration.Save();
        }

        ImGui.SameLine();

        // Window Selection Dropdown
        ImGui.SetNextItemWidth(200);
        if (ImGui.BeginCombo("##WindowToDelete", SelectedWindowToDelete?.Config.Name ?? "Select Window"))
        {
            foreach (var window in ButtonWindows)
            {
                if (ImGui.Selectable(window.Config.Name, SelectedWindowToDelete == window))
                {
                    SelectedWindowToDelete = window;
                }
            }
            ImGui.EndCombo();
        }

        ImGui.SameLine();

        if (ImGuiHelper.IconButton("Delete Selected", FontAwesomeIcon.Trash))
        {
            if (SelectedWindowToDelete != null)
            {
                showDeleteConfirmation = true;
                ImGui.OpenPopup("Delete Window?");
            }
        }

        DrawConfirmationPopup();

        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Spacing();

        if (ImGui.BeginTabBar("WahButtonsTabBar"))
        {
            foreach (var window in ButtonWindows)
            {
                if (ImGui.BeginTabItem(window.Config.Name))
                {
                    TabManager.DrawWindowTab(window);
                    ImGui.EndTabItem();
                }
            }
            ImGui.EndTabBar();
        }
    }

    private void DrawConfirmationPopup()
    {
        if (ImGui.BeginPopupModal("Delete Window?", ref showDeleteConfirmation,
            ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoMove))
        {
            ImGui.Text($"Are you sure you want to delete {SelectedWindowToDelete?.Config.Name}?");
            ImGui.Separator();

            if (ImGuiHelper.IconButton("Yes", FontAwesomeIcon.Check))
            {
                if (SelectedWindowToDelete != null)
                {
                    RemoveButtonWindow(SelectedWindowToDelete);
                    SelectedWindowToDelete = null;
                }
                showDeleteConfirmation = false;
                ImGui.CloseCurrentPopup();
            }

            ImGui.SameLine();

            if (ImGuiHelper.IconButton("No", FontAwesomeIcon.Times))
            {
                showDeleteConfirmation = false;
                ImGui.CloseCurrentPopup();
            }

            ImGui.EndPopup();
        }
    }

    private void AddButtonWindowFromConfig(Configuration.ButtonWindowConfig config)
    {
        var window = new ButtonWindow(Plugin, config)
        {
            IsOpen = config.IsVisible
        };
        ButtonWindows.Add(window);
        WindowSystem.AddWindow(window);
    }

    private void RemoveButtonWindow(ButtonWindow window)
    {
        ButtonWindows.Remove(window);
        WindowSystem.RemoveWindow(window);
        Configuration.Windows.Remove(window.Config);
        Configuration.Save();
    }

    public void SaveAllButtonWindows()
    {
        foreach (var window in ButtonWindows)
        {
            if (!Configuration.Windows.Contains(window.Config))
            {
                Configuration.Windows.Add(window.Config);
            }
        }
        Configuration.Save();
    }
}
